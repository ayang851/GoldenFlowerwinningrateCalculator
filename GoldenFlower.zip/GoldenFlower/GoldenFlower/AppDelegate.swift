//
//  AppDelegate.swift
//  GoldenFlower
//
//  Created by zhaoyang17 on 2022/4/21.
//

import UIKit
import CocoaLumberjack
let ddloglevel = DDLogLevel.info
@main
class AppDelegate: UIResponder, UIApplicationDelegate {


     var window: UIWindow?
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        DDLog.add(DDTTYLogger.sharedInstance!)
        self.window = UIWindow(frame: UIScreen.main.bounds)
self.window?.backgroundColor = UIColor.white
self.window?.rootViewController = UINavigationController.init(rootViewController: ViewController())
self.window?.makeKeyAndVisible()

        return true
    }

    

}

