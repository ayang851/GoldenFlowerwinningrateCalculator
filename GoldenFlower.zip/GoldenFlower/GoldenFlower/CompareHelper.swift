//
//  CompareHelper.swift
//  GoldenFlower
//
//  Created by zhaoyang17 on 2022/4/22.
//

import UIKit
//enum CombinationType:CombinationTypeRawValue{
//    case miscellaneous = 0 //杂牌
//    case pair = 1 //对子
//    case sort = 2 //顺子
//    case same = 3 //同花
//    case sortedSame = 4 //同花顺
//    case leopard = 5 //豹子
//}
class CompareHelper: NSObject {

    static func  isLeopard(poker1:PokerModel,poker2:PokerModel,poker3:PokerModel)->Bool{
        if(poker1.num! == poker2.num! && poker2.num!  == poker3.num!){ return true}
        return false
    }
    
    static func  issortedSame(poker1:PokerModel,poker2:PokerModel,poker3:PokerModel)->Bool{
        if(CompareHelper.isSort(poker1: poker1, poker2: poker2, poker3: poker3) && CompareHelper.isSame(poker1: poker1, poker2: poker2, poker3: poker3)){
            return true
        }
        return false
    }
    
    static func isSort(poker1:PokerModel,poker2:PokerModel,poker3:PokerModel)->Bool{
        if(poker1.num!.rawValue - poker2.num!.rawValue == 1 && poker2.num!.rawValue - poker3.num!.rawValue == 1){
            //普通顺子
            return true
        }
        // 1 2 3 顺子
        if(poker1.num! == .A && poker2.num! == ._3 && poker3.num! == ._2){
            //1 2 3 顺子
            return true
        }
        return false
    }
    
    
    static func  isSame(poker1:PokerModel,poker2:PokerModel,poker3:PokerModel)->Bool{
        if(poker1.dector == poker2.dector && poker2.dector == poker3.dector){
            return true
        }
        return false
    }
    
    static func  isPair(poker1:PokerModel,poker2:PokerModel,poker3:PokerModel)->Bool{
        if(CompareHelper.isLeopard(poker1: poker1, poker2: poker2, poker3: poker3)){ return false}
        if(poker1.num == poker2.num || poker2.num == poker3.num ){
            return true
        }
        return false
    }
    
    static func getPairPokerNum(poker1:PokerModel,poker2:PokerModel,poker3:PokerModel)->Int8{
        if (poker1.num == poker2.num) {
            return poker1.num!.rawValue;
        }else if(poker2.num == poker3.num){
            return poker2.num!.rawValue;
        }else if (poker1.num == poker3.num){
            return poker3.num!.rawValue;
        }
        return 0;
    }
    
    static func getPairSinglePoker(poker1:PokerModel,poker2:PokerModel,poker3:PokerModel)->PokerModel?{
        if (poker1.num == poker2.num) {
            return poker3;
        }else if(poker2.num == poker3.num){
            return poker1;
        }else if (poker1.num == poker3.num){
            return poker2;
        }
        return nil;
    }
    
    
    static func isMiscellaneous(poker1:PokerModel,poker2:PokerModel,poker3:PokerModel)->Bool{
        if(CompareHelper.isLeopard(poker1: poker1, poker2: poker2, poker3: poker3)){ return false}
        if(CompareHelper.issortedSame(poker1: poker1, poker2: poker2, poker3: poker3)){ return false}
        if(CompareHelper.isSort(poker1: poker1, poker2: poker2, poker3: poker3)){ return false}
        if(CompareHelper.isSame(poker1: poker1, poker2: poker2, poker3: poker3)){ return false}
        if(CompareHelper.isPair(poker1: poker1, poker2: poker2, poker3: poker3)){ return false}
        return true
    }
    
    /// <#Description#>
    /// - Parameters:
    ///   - combination1: <#combination1 description#>
    ///   - combination2: <#combination2 description#>
    /// - Returns: 0 相同大小 1大 -1小于
    static func compareCombination(combination1:GlodenFlowerCombination,combination2:GlodenFlowerCombination)->Int{
       
        
        //先比较牌型
        if(combination1.combinationType().rawValue > combination2.combinationType().rawValue){
            return 1;
        }else if(combination1.combinationType().rawValue < combination2.combinationType().rawValue){
            return -1;
        }else{
            //牌型相同
            let array1:Array! = combination1.pokerSet?.sorted { poker1, poker2 in
                return poker1.num!.rawValue > poker2.num!.rawValue
            }
            let poker1_1:PokerModel = array1[0]
            let poker1_2:PokerModel = array1[1]
            let poker1_3:PokerModel = array1[2]
            
            let array2:Array! = combination2.pokerSet?.sorted { poker1, poker2 in
                return poker1.num!.rawValue > poker2.num!.rawValue
            }
            let poker2_1:PokerModel = array2[0]
            let poker2_2:PokerModel = array2[1]
            let poker2_3:PokerModel = array2[2]
            var result:Int = 0
            switch(combination1.combinationType()){
            case  .leopard:
                //比较最大的一张
                if(poker1_1.num!.rawValue > poker2_1.num!.rawValue){
                    result = 1
                }else if(poker1_1.num!.rawValue < poker2_1.num!.rawValue){
                    result = -1
                }else{
                    result = 0
                }
            case .sortedSame,.same, .sort, .miscellaneous:
                //比较最大的一张
                if(poker1_1.num!.rawValue > poker2_1.num!.rawValue){
                    result = 1
                }else if(poker1_1.num!.rawValue < poker2_1.num!.rawValue){
                    result = -1
                }else{
                    //比较最大的二张
                    if(poker1_2.num!.rawValue > poker2_2.num!.rawValue){
                        result = 1
                    }else if(poker1_2.num!.rawValue < poker2_2.num!.rawValue){
                        result = -1
                    }else{
                        //比较最大的三张
                        if(poker1_3.num!.rawValue > poker2_3.num!.rawValue){
                            result = 1
                        }else if(poker1_3.num!.rawValue < poker2_3.num!.rawValue){
                            result = -1
                        }else{
                            result = 0
                        }
                    }
                }
                break;
            case .pair:
                //先比较对子
                let p1 = CompareHelper.getPairPokerNum(poker1: poker1_1, poker2: poker1_2, poker3: poker1_3)
                let p2 = CompareHelper.getPairPokerNum(poker1: poker2_1, poker2: poker2_2, poker3: poker2_3)
                if(p1 > p2){
                    result = 1
                }else if (p1 < p2){
                    result = -1
                }else{
                    let s1 = CompareHelper.getPairSinglePoker(poker1: poker1_1, poker2: poker1_2, poker3: poker1_3)
                    let s2 = CompareHelper.getPairSinglePoker(poker1: poker2_1, poker2: poker2_2, poker3: poker2_3)
                    if(s1!.num!.rawValue > s2!.num!.rawValue){
                        result = 1
                    }else if (s1!.num!.rawValue < s2!.num!.rawValue){
                        result = -1
                    }else{
                        result = 0
                    }
                }
                
                break;

            
            }
            
            return result;
            
            
        }
    }
    
    
    
}
