//
//  CompareResultView.swift
//  GoldenFlower
//
//  Created by zhaoyang17 on 2022/4/25.
//

import UIKit

class CompareResultView: UIView {
    lazy var titleLabel : UILabel = {
        let label = UILabel.init()
        label.text = "胜率:"
        label.font = UIFont.systemFont(ofSize: 18)
        label.textColor = UIColor.white
        return label
    }()
    
    lazy var resultLabel : UILabel = {
        let label = UILabel.init()
        label.text = "100"
        label.font = UIFont.systemFont(ofSize: 40)
        label.textColor = UIColor.v_color(hex: 0xfe0000)
        return label
    }()
    
    lazy var prectLabel : UILabel = {
        let label = UILabel.init()
        label.text = "%"
        label.font = UIFont.systemFont(ofSize: 18)
        label.textColor = UIColor.white
        return label
    }()
    
    
    lazy var memoLabel : UILabel = {
        let label = UILabel.init()
        label.text = "选择手牌开始计算胜率"
        label.font = UIFont.systemFont(ofSize: 16)
        label.textColor = UIColor.white
        return label
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.addSubview(self.titleLabel)
        self.addSubview(self.resultLabel)
        self.addSubview(self.prectLabel)
        self.addSubview(self.memoLabel)
        self.titleLabel.snp_makeConstraints { make in
            make.leading.equalTo(vidaa_MarginHor(0))
            make.top.equalTo(vidaa_MarginHor(16))
        }
        
        self.resultLabel.snp_makeConstraints { make in
            make.centerX.equalTo(self.snp_centerX)
            make.centerY.equalTo(self.snp_centerY)
        }
        
        self.prectLabel.snp_makeConstraints { make in
            make.leading.equalTo(self.resultLabel.snp_trailing).offset(vidaa_MarginHor(5))
            make.bottom.equalTo(self.resultLabel.snp_bottom)
        }
        
        self.memoLabel.snp_makeConstraints { make in
            make.centerX.equalTo(self.snp_centerX)
            make.centerY.equalTo(self.snp_centerY)
        }
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setResult(prection:Float){
        self.resultLabel.text = String.init(format: "%.1f", prection)
        self.titleLabel.isHidden = false
        self.resultLabel.isHidden = false
        self.prectLabel.isHidden = false
        self.memoLabel.isHidden = true
    }
    
    func clearData(){
        self.memoLabel.text = "选择手牌开始计算胜率"
        self.titleLabel.isHidden = true
        self.resultLabel.isHidden = true
        self.prectLabel.isHidden = true
        self.memoLabel.isHidden = false
    }
    
    func showLoading(){
        self.memoLabel.text = "计算中..."
        self.titleLabel.isHidden = true
        self.resultLabel.isHidden = true
        self.prectLabel.isHidden = true
        self.memoLabel.isHidden = false
    }
    
}
