//
//  GameManger.swift
//  GoldenFlower
//
//  Created by zhaoyang17 on 2022/4/21.
//

import UIKit
import CocoaLumberjack

protocol GameMangerDelegate:AnyObject{
    func gameResult(result:Float)
}


class GameManger: NSObject {
    var delegate:GameMangerDelegate?
    var userCount : Int = 6
    var currentUserCombination:GlodenFlowerCombination?
    static let shared = GameManger()
    //标准扑克 除去大小王
    lazy var stand52Cards: Set<PokerModel> = {
        return PokerSetGentor.gentorStand52Cards()
    }()
 
    var otherCards:Set<PokerModel>? //除去本人的其余牌
    override init() {
        super.init()
    }
    
    func addCurrentUserPoker(poker:PokerModel){
        if currentUserCombination == nil {
            currentUserCombination = GlodenFlowerCombination(set: nil)
        }
        currentUserCombination?.addPoker(poker: poker)
        if(currentUserCombination?.pokerSet?.count == 3){
            //完成了3张牌的添加
            gentorOtherCombination(combination: currentUserCombination!)
            startSimulation()
        }
    }
    
    func setCurrentUserCombination(poker1:PokerModel,poker2:PokerModel,poker3:PokerModel){
        currentUserCombination = GlodenFlowerCombination(array: [poker1,poker2,poker3])
        gentorOtherCombination(combination: currentUserCombination!)
        startSimulation()
    }
    
    func gentorOtherCombination(combination:GlodenFlowerCombination){
        otherCards = PokerSetGentor.genterOtherPokeSet(exceptSet: combination.pokerSet, allSet: stand52Cards)
    }
    
    func changeOrder(){
        
    }
    
    func startSimulation(){
        DDLogInfo("=============开始模拟=============")
//        var finalResultArray = Array<Bool>()
        let sumCount = 10000
        let fpokerArray:Array<PokerModel> = self.otherCards?.sorted(by: { p1, p2 in
            return true
        }) ?? Array<PokerModel>() ;
        //计算胜率
        var winCount = 0
        
        for _  in 1...sumCount{
            var comArray:Array<GlodenFlowerCombination> = Array<GlodenFlowerCombination>()
            var pokerArray = fpokerArray;
            //发牌
            for _ in 0...(self.userCount - 1){
                let r1:Int =  Int(arc4random() % UInt32(pokerArray.count))
                let p1 = pokerArray[r1]
                pokerArray.remove(at: Int(r1))
                
                let r2:Int =  Int(arc4random() % UInt32(pokerArray.count))
                let p2 = pokerArray[r2]
                pokerArray.remove(at: Int(r2))
                
                let r3:Int =  Int(arc4random() % UInt32(pokerArray.count))
                let p3 = pokerArray[r3]
                pokerArray.remove(at: Int(r3))
                
                let com:GlodenFlowerCombination = GlodenFlowerCombination(array: [p1,p2,p3])
                comArray.append(com)
            }
            //模拟发牌完成 开始计算获胜概率
            var isLoss = false
            for item:GlodenFlowerCombination in comArray{
                if (CompareHelper.compareCombination(combination1: self.currentUserCombination!, combination2: item) == -1){
                    //小于其他玩家手牌
                    isLoss = true;
                    break;
                }
            }
            if (!isLoss){
                winCount =  winCount + 1
            }
//            finalResultArray.append(!finalResult)
//            DDLogInfo("=============模拟结果=============")
//            let r = isLoss ?"失败":"胜利"
//            DDLogInfo("第\(i)次比赛结果:\(r)")
//            DDLogInfo("手牌:\(currentUserCombination!)")
//            for(index,item) in comArray.enumerated(){
//                DDLogInfo("玩家\(index):\(item)")
//            }
        }
       
//        for item in finalResultArray{
//            if item == true { winCount = winCount + 1}
//        }
        
        DDLogInfo("=============最终模拟结果=============")
        let winPrect:Float = Float(winCount)/Float(sumCount) * 100
        DDLogInfo("玩家总人数:\(userCount),胜率:\(winPrect)%")
        DDLogInfo("手牌:\(currentUserCombination!)")
        DDLogInfo("=============结束模拟=============")
        self.delegate?.gameResult(result: winPrect)
        
        
    }
   
    
       
    

}
