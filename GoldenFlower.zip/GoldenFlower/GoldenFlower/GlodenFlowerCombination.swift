//
//  GlodenFlowerCombination.swift
//  GoldenFlower
//
//  Created by zhaoyang17 on 2022/4/21.
//

import UIKit
typealias CombinationTypeRawValue = Int8
enum CombinationType:CombinationTypeRawValue{
    case miscellaneous = 0 //杂牌
    case pair = 1 //对子
    case sort = 2 //顺子
    case same = 3 //同花
    case sortedSame = 4 //同花顺
    case leopard = 5 //豹子
}

class GlodenFlowerCombination: NSObject {
    var pokerSet:Set<PokerModel>?
//    var pokeerWeight:Int64?
    init(set:Set<PokerModel>?) {
        super.init()
        if(set != nil){
            pokerSet = set
        }else{
            pokerSet = Set()
        }
    }
    init(array:Array<PokerModel>?) {
        super.init()
        if(array != nil){
            pokerSet = Set(array!)
        }else{
            pokerSet = Set()
        }
    }

    func addPoker(poker:PokerModel?){
        if (poker == nil){ return}
        if(pokerSet!.count >= 3){ return}
        pokerSet?.insert(poker!)
    }
    
    func combinationType()->CombinationType{
        let array:Array! = pokerSet?.sorted { poker1, poker2 in
            return poker1.num!.rawValue > poker2.num!.rawValue
        }
        let poker1:PokerModel = array[0]
        let poker2:PokerModel = array[1]
        let poker3:PokerModel = array[2]
        if(CompareHelper.isLeopard(poker1: poker1, poker2: poker2, poker3: poker3)){return .leopard}
        if(CompareHelper.issortedSame(poker1: poker1, poker2: poker2, poker3: poker3)){return .sortedSame}
        if(CompareHelper.isSame(poker1: poker1, poker2: poker2, poker3: poker3)){return .same}
        if(CompareHelper.isSort(poker1: poker1, poker2: poker2, poker3: poker3)){return .sort}
        if(CompareHelper.isPair(poker1: poker1, poker2: poker2, poker3: poker3)){return .pair}
        return .miscellaneous
    }
    override var description: String{
        let array:Array! = pokerSet?.sorted { poker1, poker2 in
            return poker1.num!.rawValue > poker2.num!.rawValue
        }
        let poker1:PokerModel = array[0]
        let poker2:PokerModel = array[1]
        let poker3:PokerModel = array[2]
        return String(format: "牌型:%@=>%@,%@,%@", self.combinationTypeName(),poker1,poker2,poker3)
    }
    func combinationTypeName()->String{
        let array:Array! = pokerSet?.sorted { poker1, poker2 in
            return poker1.num!.rawValue > poker2.num!.rawValue
        }
        let poker1:PokerModel = array[0]
        let poker2:PokerModel = array[1]
        let poker3:PokerModel = array[2]
        if(CompareHelper.isLeopard(poker1: poker1, poker2: poker2, poker3: poker3)){return "豹子"}
        if(CompareHelper.issortedSame(poker1: poker1, poker2: poker2, poker3: poker3)){return "顺金"}
        if(CompareHelper.isSame(poker1: poker1, poker2: poker2, poker3: poker3)){return "同花"}
        if(CompareHelper.isSort(poker1: poker1, poker2: poker2, poker3: poker3)){return "顺子"}
        if(CompareHelper.isPair(poker1: poker1, poker2: poker2, poker3: poker3)){return "对子"}
        return "杂牌"
    }
    
//    func weighted()->Int64{
//        let array:Array! = pokerSet?.sorted { poker1, poker2 in
//            return poker1.num!.rawValue > poker2.num!.rawValue
//        }
//        let poker1:PokerModel = array[0]
//        let poker2:PokerModel = array[1]
//        let poker3:PokerModel = array[2]
//        var weight:Int64 = 0
//        let w:Int = Int(self.combinationType().rawValue);
//        let w1 = (poker1.num!.rawValue) << (w*7)
//    }
    
}
