//
//  InfoViewController.swift
//  GoldenFlower
//
//  Created by zhaoyang17 on 2022/4/25.
//

import UIKit

class InfoViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "规则说明"
        self.view.backgroundColor = UIColor.v_color(hex: 0x14121B)
        self.navigationItem.leftBarButtonItem = UIBarButtonItem.init(image: UIImage(named: "ic_arrow_left"),  style: UIBarButtonItem.Style.plain, target: self, action: #selector(back))
        
        let label:UILabel = UILabel()
        label.textColor = UIColor.white
        label.font = UIFont.systemFont(ofSize: 16)
        label.numberOfLines = 0
        self.view.addSubview(label)
        label.snp.makeConstraints { make in
            make.leading.equalTo(vidaa_MarginHor(16))
            make.trailing.equalTo(-vidaa_MarginHor(16))
            make.top.equalTo(vidaa_MarginHor(16))
        }
        label.text = "游戏使用一副除去大小王的扑克牌，共4个花色52张牌。\n1、豹子（AAA最大，222最小）。\n2、同花顺（AKQ最大，A23最小）。\n3、同花（AKQ最大，352最小）。\n4、顺子（AKQ最大，A23最小）。\n5、对子（AAK最大，223最小）。\n6、单张（AKJ最大，352最小）。\n\n大小规则：1>2>3>4>5>6 \n\n算法说明：通过上万次模拟对比，并统计结果，更接近真实情型，相同手牌可能会存在极小误差。"
        
    }
    
    @objc func back(){
        self.navigationController?.popViewController(animated: true)
    }


}
