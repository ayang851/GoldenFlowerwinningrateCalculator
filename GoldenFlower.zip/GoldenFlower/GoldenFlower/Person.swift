//
//  Person.swift
//  GoldenFlower
//
//  Created by zhaoyang17 on 2022/4/21.
//

import UIKit

class Person: NSObject {

//    var 
}
