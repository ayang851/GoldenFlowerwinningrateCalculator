//
//  PersonCountPicker.swift
//  GoldenFlower
//
//  Created by zhaoyang17 on 2022/4/25.
//

import UIKit
import PickerView
protocol PersonCountPickerDelegate:AnyObject{
    func numDidSelect(personCount:Int)
}
class PersonCountPicker: UIView {
    
    var deleagte:PersonCountPickerDelegate?
    
    var selectedNum:Int = 6
    lazy var numArray: Array<Int> = {
        return [2,3,4,5,6,7,8,9,10,11,12,13,14]
    }()
    lazy var numPicker: PickerView = {
        let picker = PickerView()
        picker.delegate = self
        picker.dataSource = self
        picker.selectionStyle = PickerView.SelectionStyle.overlay
        return picker
    }()
    lazy var cancelBtn: UIButton = {
        let btn = UIButton(type: .custom)
        btn.setTitle("取消", for: .normal)
        btn.titleLabel?.font = UIFont.systemFont(ofSize: 16)
        btn.setTitleColor(UIColor.v_color(hex: 0x777777), for: .normal)
        btn.addTarget(self, action: #selector(cancelBtnClicked(btn:)), for: .touchUpInside)
        return btn
    }()
    
    lazy var sureBtn: UIButton = {
        let btn = UIButton(type: .custom)
        btn.setTitle("确定", for: .normal)
        btn.titleLabel?.font = UIFont.systemFont(ofSize: 16)
        btn.setTitleColor(UIColor.v_color(hex: 0xfe0000), for: .normal)
        btn.addTarget(self, action: #selector(sureBtnClicked(btn:)), for: .touchUpInside)
        return btn
    }()
    
    lazy var bottomView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.white
        view.layer.cornerRadius = 6
        view.layer.masksToBounds = true
        view.addSubview(self.cancelBtn)
        view.addSubview(self.sureBtn)
        
        return view
    }()
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor =  UIColor.clear
        self.addSubview(self.bottomView)
        self.bottomView.snp_makeConstraints { make in
            make.leading.equalTo(vidaa_MarginHor(16))
            make.trailing.equalTo(-vidaa_MarginHor(16))
            make.height.equalTo(vidaa_MarginHor(48))
            make.bottom.equalTo(self.snp_bottom).offset(-vidaa_MarginHor(20))
        }
        self.cancelBtn.snp_makeConstraints { make in
            make.leading.equalTo(0)
            make.bottom.equalTo(self.bottomView.snp_bottom)
            make.height.equalTo(vidaa_MarginHor(48))
            make.width.equalTo((SCREEN_WIDTH - vidaa_MarginHor(32))/2.0)
        }
        self.sureBtn.snp_makeConstraints { make in
            make.leading.equalTo(self.cancelBtn.snp_trailing)
            make.bottom.equalTo(self.bottomView.snp_bottom)
            make.height.equalTo(vidaa_MarginHor(48))
            make.width.equalTo((SCREEN_WIDTH - vidaa_MarginHor(32))/2.0)
        }
        let bgView:UIView = UIView()
        bgView.backgroundColor = UIColor.white
        bgView.layer.cornerRadius = 6
        bgView.layer.masksToBounds = true
        self.addSubview(bgView)
        bgView.snp_makeConstraints { make in
            make.leading.equalTo(vidaa_MarginHor(16))
            make.trailing.equalTo(-vidaa_MarginHor(16))
            make.top.equalTo(0)
            make.bottom.equalTo(self.bottomView.snp_top).offset(-vidaa_MarginHor(16))
        }
        
        bgView.addSubview(numPicker)
        numPicker.snp_makeConstraints { make in
            make.leading.equalTo(vidaa_MarginHor(0))
            make.width.equalTo(bgView.snp_width)
            make.top.equalTo(vidaa_MarginHor(6))
            make.bottom.equalTo(-vidaa_MarginHor(6))
        }
        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    @objc func cancelBtnClicked(btn:UIButton){
        self.isUserInteractionEnabled = false
        UIView.animate(withDuration: 0.25, delay: 0, options: .curveEaseInOut) {
            self.isHidden = true
        } completion: { result in
            self.removeFromSuperview()
        }

    }
    
    func show(inView:UIView){
        self.isUserInteractionEnabled = true
        self.isHidden = true
        inView.addSubview(self)
        UIView.animate(withDuration: 0.25, delay: 0, options: .curveEaseInOut) {
            self.isHidden = false
        } completion: { result in
            
        }
    }
    @objc func sureBtnClicked(btn:UIButton){
        self.deleagte?.numDidSelect(personCount: selectedNum)
        self.isUserInteractionEnabled = false
        UIView.animate(withDuration: 0.25, delay: 0, options: .curveEaseInOut) {
            self.isHidden = true
        } completion: { result in
            self.removeFromSuperview()
        }

    }
}
extension PersonCountPicker: PickerViewDataSource {
    
    // MARK: - PickerViewDataSource
    
    func pickerViewNumberOfRows(_ pickerView: PickerView) -> Int {
            return numArray.count
    }
    
    func pickerView(_ pickerView: PickerView, titleForRow row: Int) -> String {
        return String(self.numArray[row])
    }
    
}

extension PersonCountPicker: PickerViewDelegate {
    
    // MARK: - PickerViewDelegate
    
    func pickerViewHeightForRows(_ pickerView: PickerView) -> CGFloat {
        return vidaa_MarginHor(50)
    }

    func pickerView(_ pickerView: PickerView, didSelectRow row: Int) {
        selectedNum = self.numArray[row]
        
    }
    
    func pickerView(_ pickerView: PickerView, styleForLabel label: UILabel, highlighted: Bool) {
        label.textAlignment = .center
        if #available(iOS 8.2, *) {
            if (highlighted) {
                label.font = UIFont.systemFont(ofSize: 26.0, weight: UIFont.Weight.light)
            } else {
                label.font = UIFont.systemFont(ofSize: 18.0, weight: UIFont.Weight.light)
            }
        } else {
            if (highlighted) {
                label.font = UIFont(name: "HelveticaNeue-Light", size: 18.0)
            } else {
                label.font = UIFont(name: "HelveticaNeue-Light", size: 26.0)
            }
        }
        
        if (highlighted) {
            label.textColor = self.tintColor
        } else {
            label.textColor = UIColor(red: 161.0/255.0, green: 161.0/255.0, blue: 161.0/255.0, alpha: 1.0)
        }
    }
    
}
