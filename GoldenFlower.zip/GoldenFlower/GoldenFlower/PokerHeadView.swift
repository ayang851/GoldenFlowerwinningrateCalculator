//
//  PokerHeadView.swift
//  GoldenFlower
//
//  Created by zhaoyang17 on 2022/4/24.
//

import UIKit

protocol PokerHeadViewDelegate:AnyObject{
    func clearBtnClicked()
}

class PokerHeadView: UICollectionReusableView {
    var delegate:PokerHeadViewDelegate?
    lazy var titleLabel : UILabel = {
        let label = UILabel.init()
        label.text = "选择手牌:"
        label.font = UIFont.systemFont(ofSize: 16)
        label.textColor = UIColor.white
        return label
    }()
    
    lazy var clearBtn: UIButton = {
        let btn = UIButton(type: .custom)
        btn.setTitle("清空", for: .normal)
        btn.titleLabel?.font = UIFont.systemFont(ofSize: 16)
        btn.setTitleColor(UIColor.v_color(hex: 0xeeeeee), for: .normal)
        btn.addTarget(self, action: #selector(clearBtnClicked(btn:)), for: .touchUpInside)
        return btn
        
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.addSubview(self.titleLabel)
        self.titleLabel.snp_makeConstraints { make in
            make.leading.equalTo(0)
            make.top.equalTo(self)
        }
        
        self.addSubview(self.clearBtn)
        self.clearBtn.snp_makeConstraints { make in
            make.trailing.equalTo(0)
            make.centerY.equalTo(self.titleLabel.snp_centerY)
            make.height.equalTo(self)
//            make.width.equalTo(vidaa_MarginHor(60))
        }
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    @objc func clearBtnClicked(btn:UIButton){
        self.delegate?.clearBtnClicked()
    }
}
