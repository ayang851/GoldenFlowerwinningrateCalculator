//
//  PokerModel.swift
//  GoldenFlower
//
//  Created by zhaoyang17 on 2022/4/21.
//

import UIKit
typealias PokerNumRawValue = Int8
enum PokerNum:PokerNumRawValue{
    case _2 =  2
    case _3 = 3
    case _4 = 4
    case _5 = 5
    case _6 = 6
    case _7 = 7
    case _8 = 8
    case _9 = 9
    case _10 = 10
    case J = 11
    case Q = 12
    case K = 13
    case A = 14
    
    func title()->String{
        switch(self){
        case ._2: return "2"
        case ._3: return "3"
        case ._4: return "4"
        case ._5: return "5"
        case ._6: return "6"
        case ._7: return "7"
        case ._8: return "8"
        case ._9: return "9"
        case ._10: return "10"
        case .J: return "J"
        case .Q:
            return "Q"
        case .K:
            return "K"
        case .A:
            return "A"
        }
    }
    
    static func allNum()->Array<PokerNum>{
        return [PokerNum._2,PokerNum._3,PokerNum._4,PokerNum._5,PokerNum._6,PokerNum._7,PokerNum._8,PokerNum._9,PokerNum._10,PokerNum.J,PokerNum.Q,PokerNum.K,PokerNum.A]
    }
    
    static func getPokerImageName(dector:PokerDecor)->String{
        switch (dector){
        case .Heart: return "hongxin"
        case .PlumBlossom: return "meihua"
        case .Spade: return "heitao"
        case .SquarePiece: return "fangpian"
        }
    }
}

typealias PokerDecorRawValue = Int8
enum PokerDecor{
    case Heart//红桃
    case Spade//黑桃
    case PlumBlossom //梅花
    case SquarePiece//方片
    
    func title()->String{
        switch (self){
        case .Heart: return "红桃"
        case .Spade:
            return "黑桃"
        case .PlumBlossom:
            return "梅花"
        case .SquarePiece:
            return "方片"
        }
    }
    
    static func allDectors()->Array<PokerDecor>{
        return [PokerDecor.Heart,PokerDecor.Spade,PokerDecor.PlumBlossom,PokerDecor.SquarePiece]
    }
    
}



class PokerModel: NSObject {
    let num:PokerNum?
    let dector:PokerDecor?
    init(num:PokerNum,dector:PokerDecor) {
        self.num = num
        self.dector = dector
    }
    
    override var description: String{
        return String(format: "%@%@", self.dector!.title(),self.num!.title())
    }
    
    
    func isEqualTo(poker:PokerModel) -> Bool {
        return poker.dector == self.dector && self.num == poker.num
    }
  
}
