//
//  PokerPickerView.swift
//  GoldenFlower
//
//  Created by zhaoyang17 on 2022/4/24.
//

import UIKit
import PickerView
protocol PokerPickerDelegate:AnyObject{
    func pokerDidSelect(dector:PokerDecor,num:PokerNum,pokerIndex:Int)
}

class PokerPickerView: UIView {

    var delegate:PokerPickerDelegate?
    var pokerIndex:Int = 0
    let numArray = PokerNum.allNum()
    let dectorArray = PokerDecor.allDectors()
    var selectedNum:PokerNum?
    var selectedDector:PokerDecor?
    lazy var dectorPicker: PickerView = {
        let picker = PickerView()
        picker.delegate = self
        picker.dataSource = self
        picker.selectionStyle = PickerView.SelectionStyle.overlay
        return picker
    }()
    
    lazy var numberPicker: PickerView = {
        let picker = PickerView()
        picker.delegate = self
        picker.dataSource = self
        picker.selectionStyle = PickerView.SelectionStyle.overlay
        return picker
    }()
    
    lazy var cancelBtn: UIButton = {
        let btn = UIButton(type: .custom)
        btn.setTitle("取消", for: .normal)
        btn.titleLabel?.font = UIFont.systemFont(ofSize: 16)
        btn.setTitleColor(UIColor.v_color(hex: 0x777777), for: .normal)
        btn.addTarget(self, action: #selector(cancelBtnClicked(btn:)), for: .touchUpInside)
        return btn
    }()
    
    lazy var sureBtn: UIButton = {
        let btn = UIButton(type: .custom)
        btn.setTitle("确定", for: .normal)
        btn.titleLabel?.font = UIFont.systemFont(ofSize: 16)
        btn.setTitleColor(UIColor.v_color(hex: 0xfe0000), for: .normal)
        btn.addTarget(self, action: #selector(sureBtnClicked(btn:)), for: .touchUpInside)
        return btn
    }()
    
    lazy var bottomView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.white
        view.layer.cornerRadius = 6
        view.layer.masksToBounds = true
        view.addSubview(self.cancelBtn)
        view.addSubview(self.sureBtn)
        
        return view
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor =  UIColor.clear
        self.addSubview(self.bottomView)
        self.bottomView.snp_makeConstraints { make in
            make.leading.equalTo(vidaa_MarginHor(16))
            make.trailing.equalTo(-vidaa_MarginHor(16))
            make.height.equalTo(vidaa_MarginHor(48))
            make.bottom.equalTo(self.snp_bottom).offset(-vidaa_MarginHor(20))
        }
        self.cancelBtn.snp_makeConstraints { make in
            make.leading.equalTo(0)
            make.bottom.equalTo(self.bottomView.snp_bottom)
            make.height.equalTo(vidaa_MarginHor(48))
            make.width.equalTo((SCREEN_WIDTH - vidaa_MarginHor(32))/2.0)
        }
        self.sureBtn.snp_makeConstraints { make in
            make.leading.equalTo(self.cancelBtn.snp_trailing)
            make.bottom.equalTo(self.bottomView.snp_bottom)
            make.height.equalTo(vidaa_MarginHor(48))
            make.width.equalTo((SCREEN_WIDTH - vidaa_MarginHor(32))/2.0)
        }
        let bgView:UIView = UIView()
        bgView.backgroundColor = UIColor.white
        bgView.layer.cornerRadius = 6
        bgView.layer.masksToBounds = true
        self.addSubview(bgView)
        bgView.snp_makeConstraints { make in
            make.leading.equalTo(vidaa_MarginHor(16))
            make.trailing.equalTo(-vidaa_MarginHor(16))
            make.top.equalTo(0)
            make.bottom.equalTo(self.bottomView.snp_top).offset(-vidaa_MarginHor(16))
        }
        
        bgView.addSubview(dectorPicker)
        dectorPicker.snp_makeConstraints { make in
            make.leading.equalTo(vidaa_MarginHor(0))
            make.width.equalTo(self.cancelBtn.snp_width)
            make.top.equalTo(vidaa_MarginHor(6))
            make.bottom.equalTo(-vidaa_MarginHor(6))
        }
        bgView.addSubview(self.numberPicker)
        
        numberPicker.snp_makeConstraints { make in
            make.leading.equalTo(dectorPicker.snp_trailing)
            make.width.equalTo(self.dectorPicker.snp_width)
            make.top.equalTo(vidaa_MarginHor(6))
            make.bottom.equalTo(-vidaa_MarginHor(6))
        }
        
        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    @objc func cancelBtnClicked(btn:UIButton){
        self.isUserInteractionEnabled = false
        UIView.animate(withDuration: 0.25, delay: 0, options: .curveEaseInOut) {
            self.isHidden = true
        } completion: { result in
            self.removeFromSuperview()
        }

    }
    
    func show(inView:UIView){
        self.isUserInteractionEnabled = true
        self.isHidden = true
        inView.addSubview(self)
        UIView.animate(withDuration: 0.25, delay: 0, options: .curveEaseInOut) {
            self.isHidden = false
        } completion: { result in
            
        }
    }
    @objc func sureBtnClicked(btn:UIButton){
        
        self.delegate?.pokerDidSelect(dector: self.dectorArray[self.dectorPicker.currentSelectedRow], num: self.numArray[self.numberPicker.currentSelectedRow],pokerIndex: self.pokerIndex)
        
        self.isUserInteractionEnabled = false
        UIView.animate(withDuration: 0.25, delay: 0, options: .curveEaseInOut) {
            self.isHidden = true
        } completion: { result in
            self.removeFromSuperview()
        }

    }
}
extension PokerPickerView: PickerViewDataSource {
    
    // MARK: - PickerViewDataSource
    
    func pickerViewNumberOfRows(_ pickerView: PickerView) -> Int {
        if(pickerView == self.dectorPicker){
            return dectorArray.count
        }else{
            return numArray.count
        }
    }
    
    func pickerView(_ pickerView: PickerView, titleForRow row: Int) -> String {
        if(pickerView == self.dectorPicker){
            return self.dectorArray[row].title()
        }else{
            return self.numArray[row].title()
        }
    }
    
}

extension PokerPickerView: PickerViewDelegate {
    
    // MARK: - PickerViewDelegate
    
    func pickerViewHeightForRows(_ pickerView: PickerView) -> CGFloat {
        return vidaa_MarginHor(50)
    }

    func pickerView(_ pickerView: PickerView, didSelectRow row: Int) {
        if(pickerView == self.dectorPicker){
            selectedDector = self.dectorArray[row]
        }else{
            selectedNum = self.numArray[row]
        }
    }
    
    func pickerView(_ pickerView: PickerView, styleForLabel label: UILabel, highlighted: Bool) {
        label.textAlignment = .center
        if #available(iOS 8.2, *) {
            if (highlighted) {
                label.font = UIFont.systemFont(ofSize: 26.0, weight: UIFont.Weight.light)
            } else {
                label.font = UIFont.systemFont(ofSize: 18.0, weight: UIFont.Weight.light)
            }
        } else {
            if (highlighted) {
                label.font = UIFont(name: "HelveticaNeue-Light", size: 18.0)
            } else {
                label.font = UIFont(name: "HelveticaNeue-Light", size: 26.0)
            }
        }
        
        if (highlighted) {
            label.textColor = self.tintColor
        } else {
            label.textColor = UIColor(red: 161.0/255.0, green: 161.0/255.0, blue: 161.0/255.0, alpha: 1.0)
        }
    }
    
    func pickerView(_ pickerView: PickerView, viewForRow row: Int, highlighted: Bool, reusingView view: UIView?) -> UIView? {
        if(pickerView == self.numberPicker){
            return view
        }
        var customView = view
        let imageTag = 100
        if (customView == nil) {
            var frame = pickerView.frame
            frame.origin = CGPoint.zero
            frame.size.height = 50
            customView = UIView(frame: frame)
            
            let imageView = UIImageView(frame: CGRect.init(x: 0, y: 0, width: vidaa_MarginHor(30), height: vidaa_MarginHor(30)))
            imageView.tag = imageTag
            imageView.contentMode = .scaleAspectFill
            imageView.image = UIImage(named: PokerNum.getPokerImageName(dector: self.dectorArray[row]))
            imageView.clipsToBounds = true
            imageView.center = customView!.center
            customView?.addSubview(imageView)
        }
        
        let imageView = customView?.viewWithTag(imageTag) as? UIImageView
//        let label = customView?.viewWithTag(labelTag) as? UILabel
        
//        switch presentationType {
//        case .numbers(_, _):
//            label?.text = numbers[row]
//        case .names(_, _):
//            label?.text = osxNames[row]
//        }
        
        let alpha: CGFloat = highlighted ? 1.0 : 0.5
        
        imageView?.alpha = alpha
//        label?.alpha = alpha
        
        return customView
    }
    
}
