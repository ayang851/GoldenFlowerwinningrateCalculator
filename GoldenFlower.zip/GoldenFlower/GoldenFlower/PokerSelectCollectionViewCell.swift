//
//  PokerSelectCollectionViewCell.swift
//  GoldenFlower
//
//  Created by zhaoyang17 on 2022/4/24.
//

import UIKit

class PokerSelectCollectionViewCell: UICollectionViewCell {
    
    lazy var blankView: BlankPokerView = {
        return BlankPokerView.init(frame: self.frame)
    }()
    lazy var pokerView: PokerView = {
        return PokerView.init(frame: self.frame)
    }()
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.layer.cornerRadius = 6
        self.layer.masksToBounds = true
    }
    
    func poker(poker:PokerModel?){
        self.blankView.removeFromSuperview()
        self.pokerView.removeFromSuperview()
        if(poker == nil){
            self.contentView.addSubview(self.blankView)
            self.blankView.snp_makeConstraints { make in
                make.top.leading.trailing.equalTo(self.contentView)
                make.bottom.equalTo(self.contentView.snp_bottom)
            }
        }else{
            self.contentView.addSubview(self.pokerView)
            self.pokerView.poker(poker: poker!)
            self.pokerView.backgroundColor = UIColor.white
            self.pokerView.snp_makeConstraints { make in
                make.top.leading.trailing.equalTo(self.contentView)
                make.bottom.equalTo(self.contentView.snp_bottom)
            }
           
        }
        
    }
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
