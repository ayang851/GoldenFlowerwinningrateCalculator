//
//  PokerSetGentor.swift
//  GoldenFlower
//
//  Created by zhaoyang17 on 2022/4/21.
//

import UIKit

class PokerSetGentor: NSObject {
    static func gentorStand52Cards()->(Set<PokerModel>){
        var cardsSet = Set<PokerModel>()
        for num in PokerNum.allNum(){
            for dector in PokerDecor.allDectors(){
                cardsSet.insert(PokerModel(num: num, dector: dector))
            }
        }
        return cardsSet
    }
    
    static func genterOtherPokeSet(exceptSet:Set<PokerModel>?,allSet:Set<PokerModel>)->(Set<PokerModel>){
        var newSet = allSet
        for exc in exceptSet!{
            for s in allSet{
                if(exc.num == s.num && exc.dector == s.dector){
                    newSet.remove(s)
                }
            }
        }
        return newSet
    }
}
