//
//  PokerView.swift
//  GoldenFlower
//
//  Created by zhaoyang17 on 2022/4/24.
//

import UIKit

class PokerView: UIView {
    lazy var imageViewSmall: UIImageView = {
        let imageView = UIImageView.init(image: UIImage(named: "hongxin"))
        imageView.contentMode = .scaleAspectFill
        return imageView
    }()
    
    
    lazy var imageViewBig: UIImageView = {
        let imageView = UIImageView.init(image: UIImage(named: "hongxin"))
        imageView.contentMode = .scaleAspectFill
        return imageView
    }()
    
    
    lazy var titleLabel : UILabel = {
        let label = UILabel.init()
        label.text = "A"
        label.font = UIFont.systemFont(ofSize: 16)
        label.textColor = UIColor.white
        return label
    }()

    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor.v_color(hex: 0x20242E)
        self.addSubview(imageViewSmall)
        self.addSubview(titleLabel)
        self.addSubview(imageViewBig)
        self.imageViewSmall.snp_makeConstraints { make in
            make.width.height.equalTo(vidaa_MarginHor(16))
            make.leading.top.equalTo(vidaa_MarginHor(10))
        }
        self.titleLabel.snp_makeConstraints { make in
            make.top.equalTo(self.imageViewSmall.snp_bottom).offset(vidaa_MarginHor(6))
            make.centerX.equalTo(self.imageViewSmall.snp_centerX)
        }
        imageViewBig.snp_makeConstraints { make in
            make.width.height.equalTo(vidaa_MarginHor(66))
            make.centerY.equalTo(self.snp_centerY).offset(vidaa_MarginHor(16))
            make.centerX.equalTo(self.snp_centerX)

        }
    }
    
    
    
    func poker(poker:PokerModel){
        self.imageViewSmall.image = UIImage(named: PokerNum.getPokerImageName(dector: poker.dector!))
        self.imageViewBig.image = UIImage(named: PokerNum.getPokerImageName(dector: poker.dector!))
        self.titleLabel.textColor = getPokerTileColor(dector: poker.dector!)
        self.titleLabel.text = poker.num?.title()
    }
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    func getPokerTileColor(dector:PokerDecor)->UIColor{
        switch (dector){
        case .Heart: return UIColor.v_color(hex: 0xfe1727)
        case .PlumBlossom: return UIColor.v_color(hex: 0x000000)
        case .Spade: return UIColor.v_color(hex: 0x010101)
        case .SquarePiece: return UIColor.v_color(hex: 0xfe0000)
        }
    }

    
}
