//
//  UIColor_Extension.swift
//  RemoteApp
//
//  Created by wangpeng on 2020/11/3.
//  Copyright © 2020 hisense. All rights reserved.
//

import UIKit

extension UIColor {
    /// 设置16进制颜色
    ///
    /// - Parameters:
    ///   - hex: 16进制数
    ///   - alpha: 透明度
    public static func v_color(hex: Int, alpha: CGFloat = 1.0) -> UIColor {
        return UIColor.init(red: CGFloat(Double(((hex & 0xFF0000) >> 16)) / 255.0), green: CGFloat(Double((((hex & 0xFF00) >> 8))) / 255.0), blue: CGFloat(Double(((hex & 0xFF))) / 255.0), alpha: alpha)
    }
    convenience init(hexString: String) {
            let hexString = hexString.trimmingCharacters(in: .whitespacesAndNewlines)
            let scanner = Scanner(string: hexString)
             
            if hexString.hasPrefix("#") {
                scanner.scanLocation = 1
            }
             
            var color: UInt32 = 0
            scanner.scanHexInt32(&color)
             
            let mask = 0x000000FF
            let r = Int(color >> 16) & mask
            let g = Int(color >> 8) & mask
            let b = Int(color) & mask
             
            let red   = CGFloat(r) / 255.0
            let green = CGFloat(g) / 255.0
            let blue  = CGFloat(b) / 255.0
             
            self.init(red: red, green: green, blue: blue, alpha: 1)
        }
         
        // UIColor -> Hex String
        var hexString: String? {
            var red: CGFloat = 0
            var green: CGFloat = 0
            var blue: CGFloat = 0
            var alpha: CGFloat = 0
             
            let multiplier = CGFloat(255.999999)
             
            guard self.getRed(&red, green: &green, blue: &blue, alpha: &alpha) else {
                return nil
            }
             
            if alpha == 1.0 {
                return String(
                    format: "#%02lX%02lX%02lX",
                    Int(red * multiplier),
                    Int(green * multiplier),
                    Int(blue * multiplier)
                )
            }
            else {
                return String(
                    format: "#%02lX%02lX%02lX%02lX",
                    Int(red * multiplier),
                    Int(green * multiplier),
                    Int(blue * multiplier),
                    Int(alpha * multiplier)
                )
            }
        }
    
    /**
     * 取随机色
     */
    public static func vidaa_random() -> UIColor {
        return UIColor.init(red: CGFloat(arc4random_uniform(256)) / 255.0, green: CGFloat(arc4random_uniform(256)) / 255.0, blue: CGFloat(arc4random_uniform(256)) / 255.0, alpha: 1.0)
    }
    
    /// 渐变颜色
    ///
    /// - Parameters:
    ///   - size: 范围大小
    ///   - angle: 渐变角度（0 ~ 2*Double.pi）
    ///   - startColor: 开始颜色
    ///   - endColor: 结束颜色
    public static func vidaa_gradientColor(size: CGSize, angle: Double, startColor: UIColor, endColor: UIColor) -> UIColor {
        let gradient = CAGradientLayer.init()
        gradient.frame = CGRect.init(x: 0.0, y: 0.0, width: size.width, height: size.height)
        
        // 设置开始和结束位置
        // (0,0)(1.0,0)代表水平方向渐变
        // (0,0)(0,1.0)代表竖直方向渐变
        var startPoint: CGPoint = CGPoint.init(x: 0.0, y: 0.0)
        var endPoint: CGPoint = CGPoint.init(x: 0.0, y: 0.0)
        if angle == 0.0 || angle == Double.pi {
            startPoint = CGPoint.init(x: 0.0, y: 0.0)
            endPoint = CGPoint.init(x: 1.0, y: 0.0)
        } else if angle > 0.0 && angle < Double.pi / 4 {
            startPoint = CGPoint.init(x: 0.0, y: 0.0)
            endPoint = CGPoint.init(x: 1.0, y: tan(angle))
        } else if angle == Double.pi / 4 {
            startPoint = CGPoint.init(x: 0.0, y: 0.0)
            endPoint = CGPoint.init(x: 1.0, y: 1.0)
        } else if angle > Double.pi / 4 && angle < Double.pi / 2 {
            startPoint = CGPoint.init(x: 0.0, y: 0.0)
            endPoint = CGPoint.init(x: 1.0 / tan(angle), y: 1.0)
        } else if angle == Double.pi / 2 {
            startPoint = CGPoint.init(x: 0.0, y: 0.0)
            endPoint = CGPoint.init(x: 0.0, y: 1.0)
        } else if angle > Double.pi / 2 && angle < Double.pi / 4 * 3 {
            startPoint = CGPoint.init(x: 1.0, y: 0.0)
            endPoint = CGPoint.init(x: 1.0 / tan(Double.pi - angle), y: 1.0)
        } else if angle == Double.pi / 4 * 3 {
            startPoint = CGPoint.init(x: 1.0, y: 0.0)
            endPoint = CGPoint.init(x: 0.0, y: 1.0)
        } else if angle > Double.pi / 4 * 3 && angle < Double.pi {
            startPoint = CGPoint.init(x: 1.0, y: 0.0)
            endPoint = CGPoint.init(x: 1.0, y: tan(Double.pi - angle))
        }
        
        gradient.startPoint = startPoint
        gradient.endPoint = endPoint
        gradient.colors = [startColor.cgColor, endColor.cgColor]
        
        // 生成颜色
        UIGraphicsBeginImageContext(size)
        gradient.render(in: UIGraphicsGetCurrentContext()!)
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        return UIColor.init(patternImage: image!)
    }
}
