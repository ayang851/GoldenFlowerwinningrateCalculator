//
//  Vidaa_Frame_Macro.swift
//  RemoteApp
//
//  Created by wangpeng on 2020/11/6.
//  Copyright © 2020 hisense. All rights reserved.
//

import UIKit
import SystemConfiguration.CaptiveNetwork
import AVFoundation
import Photos
import MediaPlayer

/**
 * ****定义系统相关常量****
 */
//屏幕宽
let VIDAA_SCREEN_WIDTH = UIScreen.main.bounds.width
//屏幕高
let VIDAA_SCREEN_HEIGHT = UIScreen.main.bounds.height
//UI设计图分辨率为1920*1080，对应6p机型3x图尺寸，以此机型为基准向上向下适配尺寸
let REF_WIDTH:CGFloat = 360.0
let REF_HEIGHT:CGFloat = 640.0
//是否是刘海屏型号
let VIDAA_IS_IPHONEX = Vidaa_System_Macro.isIPhoneX()
//是否是ipad系列型号
let VIDAA_IS_IPAD  = Vidaa_System_Macro.isIPad()
//导航栏高度
let VIDAA_NAVIBAR_HEIGHT : CGFloat = VIDAA_HEIGHT_SCALE * 48.0
//状态栏高度
let VIDAA_STATUSBAR_HEIGHT : CGFloat = VIDAA_IS_IPHONEX ? UIApplication.shared.statusBarFrame.height :VIDAA_HEIGHT_SCALE * 25.0
//let VIDAA_STATUSBAR_HEIGHT: CGFloat = UIApplication.shared.statusBarFrame.height

let VIDDA_TabBar = UITabBarController.init().tabBar

//@available(iOS 11.0, *)
//let VIDAA_SAFE_HEIGHT = UIApplication.shared.keyWindow?.safeAreaInsets.bottom


//var VIDAA_WINDOW: UIWindow? {
//    get{
//        if let app = UIApplication.shared.delegate as? AppDelegate {
//            return app.window
//        }
//        return nil
//    }
//}
//
//var iphoneX_Series: Float {
//    get {
//
//        if UIDevice.current.userInterfaceIdiom != UIUserInterfaceIdiom.phone{
//            debugPrint("不是iPhone， 是 \(UIDevice.current.userInterfaceIdiom.rawValue)")
//        }
//
//        if #available(iOS 11.0, *) {
//            if let bottom = VIDAA_WINDOW?.safeAreaInsets.bottom , bottom > 0 {
//                return true
//            }
//        } else {
//            debugPrint("iOS11 之前的版本")
//        }
//        return false
//    }
//}
let VIDAA_SAFE_HEIGHT : CGFloat = (VIDAA_IS_IPHONEX) ? 34.0 : 0.0

//TabBar高度
let VIDAA_TABBAR_HEIGHT : CGFloat = VIDDA_TabBar.frame.size.height + VIDAA_SAFE_HEIGHT
//TabBar安全高度

//高度比
let VIDAA_HEIGHT_SCALE = VIDAA_IS_IPAD ? VIDAA_SCREEN_HEIGHT / REF_HEIGHT : VIDAA_SCREEN_WIDTH / REF_WIDTH
//宽度比
let VIDAA_WIDTH_SCALE = VIDAA_IS_IPAD ? 1.8 : VIDAA_SCREEN_WIDTH / REF_WIDTH
//
let SCREEN_WIDTH = UIScreen.main.bounds.width
let SCREEN_HEIGHT = UIScreen.main.bounds.height

let WIDTH_SCALE = VIDAA_IS_IPAD ? 1.8 : SCREEN_WIDTH/REF_WIDTH //说明： Pad一般宽度比较宽，按照横向比例来计算，某些横向相关的尺寸会变得特别大， 因此这里特殊处理。
let HEIGHT_SCALE = VIDAA_IS_IPAD ? SCREEN_HEIGHT/REF_HEIGHT : SCREEN_WIDTH/REF_WIDTH

let MARGIN_16_HOR:CGFloat = WIDTH_SCALE*16
let MARGIN_4_HOR:CGFloat = WIDTH_SCALE*4
let MARGIN_152_VER:CGFloat = HEIGHT_SCALE*152
let MARGIN_8_HOR:CGFloat = WIDTH_SCALE*8
let MARGIN_164_VER:CGFloat = HEIGHT_SCALE*164
let NORMAL_CORNER_RADIUS:CGFloat = 8
let MARGIN_12_HOR:CGFloat = WIDTH_SCALE*12
let MARGIN_16_VER:CGFloat = HEIGHT_SCALE*16//四色键下间距
let MARGIN_10_VER:CGFloat = HEIGHT_SCALE*10
let MARGIN_54_HOR:CGFloat = WIDTH_SCALE*54
let FONT_SIZE_14:CGFloat = WIDTH_SCALE*14.0
let FONT_SIZE_16:CGFloat = WIDTH_SCALE*16.0
let MARGIN_32_6_HOR:CGFloat = WIDTH_SCALE*32
let MARGIN_6_VER:CGFloat = HEIGHT_SCALE*6
let FONT_SIZE_12:CGFloat = WIDTH_SCALE*12.0
let MARGIN_70_HOR:CGFloat = WIDTH_SCALE*70
let MARGIN_14_VER:CGFloat = HEIGHT_SCALE*14
let FONT_SIZE_28:CGFloat = WIDTH_SCALE*28.0
let FONT_SIZE_24:CGFloat = WIDTH_SCALE*24.0
let MARGIN_70_VER:CGFloat = HEIGHT_SCALE*70
let MARGIN_8_VER:CGFloat = HEIGHT_SCALE*8
let MARGIN_30_VER:CGFloat = HEIGHT_SCALE*30
let SIZE_60_HEIGHT:CGFloat = WIDTH_SCALE*60
let MARGIN_28_VER:CGFloat = HEIGHT_SCALE*28
let MARGIN_3_VER:CGFloat = HEIGHT_SCALE*3
let MARGIN_5_HOR:CGFloat = WIDTH_SCALE*5
let MARGIN_60_VER:CGFloat = HEIGHT_SCALE*60
let MARGIN_15_VER:CGFloat = HEIGHT_SCALE*15
let MARGIN_37_HOR:CGFloat = WIDTH_SCALE*37
let MARGIN_74_HOR:CGFloat = WIDTH_SCALE*74
let MARGIN_40_HOR:CGFloat = WIDTH_SCALE*56
let MARGIN_40_VER:CGFloat = HEIGHT_SCALE*44
let MARGIN_2_VER:CGFloat = HEIGHT_SCALE*2
let MARGIN_90_VER:CGFloat = HEIGHT_SCALE*90
let MARGIN_400_VER:CGFloat = HEIGHT_SCALE*400
/**
 * 计算高度
 */
func vidaa_MarginVer(_ value: CGFloat) -> CGFloat {
    return VIDAA_HEIGHT_SCALE * value
}

/**
 * 计算int高度
 */
func vidaa_Int_MarginVer(_ value: CGFloat) -> CGFloat {
    return CGFloat(Int (VIDAA_HEIGHT_SCALE * value))
}

/**
 * 计算宽度
 */
func vidaa_MarginHor(_ value: CGFloat) -> CGFloat {
    return VIDAA_WIDTH_SCALE * value
}
func marginVer(_ value: CGFloat) -> CGFloat {
    return HEIGHT_SCALE*value
}

func vidaa_Int_MarginHor(_ value: CGFloat) -> CGFloat {
    return CGFloat(Int (VIDAA_WIDTH_SCALE * value))
}

/**
 * 多语言
 */

func isPad() -> Bool {
    let modelStr = UIDevice.current.model
    print("modelStr:\(modelStr)")
    if modelStr.contains("iPad") {
        if SCREEN_WIDTH > 414 {//为了防止如下情形：app General中device设为iPhone，但是iPad运行了app，此时modelStr= “iPad”,但实际上以iPhone模式运行，此时width=320，height=480
            return true
        }
    }
    return false
}
/**
 * 获取WIFI名称
 */
//func getCurrentWifiSSID() ->  String {
//
//    var wifiName : String = ""
//    let wifiInterfaces = CNCopySupportedInterfaces()
//    if wifiInterfaces == nil {
//        return wifiName
//    }
//
//    let interfaceArr = CFBridgingRetain(wifiInterfaces!) as! Array<String>
//    if interfaceArr.count > 0 {
//        let interfaceName = interfaceArr[0] as CFString
//        let ussafeInterfaceData = CNCopyCurrentNetworkInfo(interfaceName)
//
//        if (ussafeInterfaceData != nil) {
//            let interfaceData = ussafeInterfaceData as! Dictionary<String, Any>
//            wifiName = interfaceData["SSID"]! as! String
//        }
//    }
//        return wifiName
//
//
//}

/**
 * 去设置WIFI权限
 */
func goSettingWIFI() {
    let url = NSURL.init(string: UIApplication.openSettingsURLString)
    guard url != nil else {
        return
    }
    if UIApplication.shared.canOpenURL(url! as URL) {
        if #available(iOS 10.0, *) {
            UIApplication.shared.open(url! as URL, options: [:], completionHandler: nil)
        } else {
            UIApplication.shared.openURL(url! as URL)
        }
    }
}

/**
 * 麦克风权限
 */
func openRecordServiceWithBlock(action :@escaping ((Int)->())) {
    let permissionStatus = AVAudioSession.sharedInstance().recordPermission
    if permissionStatus == AVAudioSession.RecordPermission.undetermined {
        AVAudioSession.sharedInstance().requestRecordPermission { (granted) in
            if granted {
                action(2)
            }else
            {
                action(0)
            }
        }
    } else if permissionStatus == AVAudioSession.RecordPermission.denied {
        action(0)
    } else {
        action(1)
    }
}

/**
 * UUID
 */
func getUUID() ->String {
    //将uuid 格式调整为 AD：39:F3:F4:19:FA 只取前12位，每两位加冒号分割开
    let deviceid = Vidaa_System_Macro.uuid!
    var id :[String]=[]
    for s in deviceid {
        id.append(String(s))
    }
    var newuuid = ""
    for index in 0..<id.count {
        if index < 12 {
            if index % 2 == 0 {
                newuuid = newuuid + id[index]
            }
            else if index % 2 == 1 {
                if index == 11 {
                    newuuid = newuuid + id[index]
                }
                else {
                    newuuid = newuuid + id[index] + ":"
                }
            }
        }
    }
    return newuuid
}
 
func getLocaleCode(for fullCountryName : String) -> String {
    let locales : String = ""
    for localeCode in NSLocale.isoCountryCodes {
        let identifier = NSLocale(localeIdentifier: localeCode)
        let countryName = identifier.displayName(forKey: NSLocale.Key.countryCode, value: localeCode)
        if fullCountryName.lowercased() == countryName?.lowercased() {
            return localeCode
        }
    }
    return locales
}



/**
 * 手机机型
 */
func getiPhoneModel() -> String {
    return UIDevice.current.model
}

/**
 * 手机操作系统版本
 */
func getiPhoneSystemVersion() -> String {
    return UIDevice.current.systemVersion
}

/**
 * App版本号
 */
func getAppVersionNum() -> String {
    if let dic = Bundle.main.infoDictionary {
        return dic["CFBundleShortVersionString"] as! String
    }
    return ""
}

/**
 * AppVersionCode版本号
 */
func getAppVersionCode() -> String {
    return getAppVersionNum().replacingOccurrences(of: ".", with: "")
}
/**
 * 获取相册的图片的名称
 */
func getImageName(asset: PHAsset, info: [AnyHashable : Any]?) -> String {
    var imageName = ""
    if let url = info!["PHImageFileURLKey"] {
        imageName = (url as! URL).lastPathComponent
    } else {
        let resourse = PHAssetResource.assetResources(for: asset)
        imageName = (resourse.first?.originalFilename ?? "")
        if imageName == "" {
            if let url = getFileURLFromPHAsset(description: resourse.description) {
                imageName = URL(string: url)?.lastPathComponent ?? ""
            }
        }
    }
    return imageName
}
/**
 * 获取文件的URL
 */
func getFileURLFromPHAsset(description: String) -> String? {
    let regex = try! NSRegularExpression(pattern: "(?<=fileURL: ).*(?=\\s)")
    if let result = regex.firstMatch(in: description, options: [], range: NSRange(location: 0, length: description.count)) {
        let url = String(description[Range(result.range, in: description)!])
        return url
    }
    return nil
}

/**
 * 压缩
 */
func compressOriginalImage(image :UIImage, toSize: CGSize, maxLength: NSInteger) -> Data {
    var resultImage = image
    var targetSize = toSize
    if(resultImage.size.width <= targetSize.width || resultImage.size.height <= targetSize.height) {
        return resultImage.jpegData(compressionQuality: 0.7)!
    }
    let width = resultImage.size.width
    let height = resultImage.size.height
    var targetWidth = targetSize.width
    var targetHeight = targetSize.height
    let w1 = targetWidth
    let h1 = targetWidth * height / width
    let W1 = targetHeight * width / height
    let H1 = targetHeight
    if (w1*h1 > W1*H1) {
        targetWidth = w1
        targetHeight = h1
    } else {
        targetWidth = W1
        targetHeight = H1
    }
    targetSize = CGSize.init(width: targetWidth, height: targetHeight)
    var scaleFactor :CGFloat = 0.0
    var scaledWidth = targetWidth
    var scaledHeight = targetHeight
    var thumbnailPoint = CGPoint.init(x: 0.0, y: 0.0)
    if (resultImage.size.equalTo(targetSize)) {
        let widthFactor = targetWidth / width
        let heightFactor = targetHeight / height
        if (widthFactor > heightFactor){
            scaleFactor = widthFactor
        } else {
            scaleFactor = heightFactor
        }
        scaledWidth = width * scaleFactor
        scaledHeight = height * scaleFactor
        if (widthFactor > heightFactor)
        {
            thumbnailPoint.y = (targetHeight - scaledHeight) * 0.5
        }
        else if (widthFactor < heightFactor)
        {
            thumbnailPoint.x = (targetWidth - scaledWidth) * 0.5
        }
    }
    UIGraphicsBeginImageContext(targetSize)
    var thumbnailRect = CGRect.zero
    thumbnailRect.origin = thumbnailPoint
    thumbnailRect.size.width = scaledWidth
    thumbnailRect.size.height = scaledHeight
    resultImage.draw(in: thumbnailRect)
    resultImage = UIGraphicsGetImageFromCurrentImageContext()!
    UIGraphicsEndImageContext()
    
    var data = resultImage.jpegData(compressionQuality: 0.7) ?? Data.init()
    if maxLength == 0 {
        return data
    }
    if (data.count <= maxLength) {
        return data
    }
    let dataKBytes = data.count/1024
    if dataKBytes > maxLength{
        let rate = Float(maxLength)/Float(dataKBytes)
        data = resultImage.jpegData(compressionQuality: CGFloat(rate)) ?? Data.init()
    }
    return data
}

/**
 * 前往手机设置页
 */
func gotoSettings() {
    let url = NSURL.init(string: UIApplication.openSettingsURLString)
    guard url != nil else {
        return
    }
    if UIApplication.shared.canOpenURL(url! as URL) {
        if #available(iOS 10.0, *) {
            UIApplication.shared.open(url! as URL, options: [:], completionHandler: nil)
        } else {
            UIApplication.shared.openURL(url! as URL)
        }
    }
}




/**
 * 转换成显示的时间格式
 */
func formatPlayTime(secounds:TimeInterval)->String{
    if secounds.isNaN{
        return "00:00"
    }
    let Min = Int(secounds / 60)
    let Sec = Int(secounds.truncatingRemainder(dividingBy: 60))
    return String(format: "%02d:%02d",Min, Sec)
}

/**
 * 转换成显示的时间格式
 */
func formatSyncTime(secounds:TimeInterval)->String{
    if secounds.isNaN{
        return "00:00:00"
    }
    let Hour = Int(secounds / 3600)
    let Min = Int(secounds.truncatingRemainder(dividingBy: 3600) / 60)
    let Sec = Int(secounds.truncatingRemainder(dividingBy: 60))
    return String(format: "%02d:%02d:%02d", Hour,Min, Sec)
}


/**
 * 验证邮箱是否符合规则
 */
func emailRegular(str: String) -> Bool {
    let emailPattern = "^([a-zA-Z0-9._-])+@([a-zA-Z0-9_-])+(\\.[a-zA-Z0-9_-]+)+$";
    // 正则表达式  使用caseInsensitive不区分大小写，使用Options()则区分
    let regexExpression = try? NSRegularExpression(pattern: emailPattern, options: NSRegularExpression.Options.caseInsensitive)
    if let result = regexExpression?.matches(in: str, options: NSRegularExpression.MatchingOptions(), range: NSMakeRange(0, str.count)), result.count != 0 {
        return true
    }
    return false
}



/**
 * 密码是否符合规则
 */
func passWordRegular(str: String) -> Bool {
    let passWordPattern = "^(?=.*[0-9])(?=.*[a-zA-Z])(.{8,30})$"
    // 正则表达式  使用caseInsensitive不区分大小写，使用Options()则区分
    let regexExpression = try? NSRegularExpression(pattern: passWordPattern, options: NSRegularExpression.Options.caseInsensitive)
    if let result = regexExpression?.matches(in: str, options: NSRegularExpression.MatchingOptions(), range: NSMakeRange(0, str.count)), result.count != 0 {
        return true
    }
    return false
}


/**
 * 是否是纯数字
 */
func isNumber(number:String) -> Bool {
   let pattern = "^[0-9]+$"
   if NSPredicate(format: "SELF MATCHES %@", pattern).evaluate(with: number) {
       return true
   }
   return false
}

/**
 * 验证邮箱是否符合规则
 */
func phoneNumberRegular(str: String) -> Bool {
//    let emailPattern = "^[\\-\\.\\w]+@[\\.\\-\\w]+(\\.\\w+)+$";
//    // 正则表达式  使用caseInsensitive不区分大小写，使用Options()则区分
//    let regexExpression = try? NSRegularExpression(pattern: emailPattern, options: NSRegularExpression.Options.caseInsensitive)
//    if let result = regexExpression?.matches(in: str, options: NSRegularExpression.MatchingOptions(), range: NSMakeRange(0, str.count)), result.count != 0 {
//        return true
//    }
    return (str.count != 0)
}


func getLanguageId() -> String {
    return getCurrentLanguageId()
}

func getCurrentLanguageId() -> String {
    let preferredLang = Bundle.main.preferredLocalizations.first! as NSString
    var languageId = "1"
    if preferredLang.contains("en") {
        languageId = "1"
    }
    else if preferredLang.contains("zh-Hans") || preferredLang.contains("zh-Hant") || preferredLang.contains("zh-TW") || preferredLang.contains("zh-HK") {
        languageId = "0";
    }
    else if preferredLang.contains("fr"){
        languageId = "2";
    }
    else if preferredLang.contains("ru"){
        languageId = "4";
    }
    else if preferredLang.contains("es"){
        languageId = "6";
    }
    else if preferredLang.contains("de"){
        languageId = "7";
    }
    else if preferredLang.contains("th"){
        languageId = "11";
    }
    else if preferredLang.contains("it"){
        languageId = "12";
    }
    else if preferredLang.contains("nl"){
        languageId = "13";
    }
    else if preferredLang.contains("pt"){
        languageId = "14";
    }
    else if preferredLang.contains("cs"){
        languageId = "15";
    }
    else if preferredLang.contains("hu"){
        languageId = "16";
    }
    else if preferredLang.contains("ms"){
        languageId = "20";
    } else if preferredLang.contains("tr"){
        languageId = "22";
    } else if preferredLang.contains("uz"){
        languageId = "24";
    } else if preferredLang.contains("nb"){
        languageId = "25";
    } else if preferredLang.contains("sv"){
        languageId = "26";
    } else if preferredLang.contains("da"){
        languageId = "27";
    } else if preferredLang.contains("fi"){
        languageId = "28";
    } else if preferredLang.contains("vi"){
        languageId = "29";
    } else if preferredLang.contains("uk"){
        languageId = "33";
    } else if preferredLang.contains("sk"){
        languageId = "34";
    } else if preferredLang.contains("pl"){
        languageId = "35";
    }
    return languageId
}



class Vidaa_System_Macro: NSObject {
    static let uuid = UIDevice.current.identifierForVendor?.uuidString.replacingOccurrences(of: "-", with: "")
    /**
     * IPAD
     */
    class func isIPad() -> Bool {
        let modelStr = UIDevice.current.model
        if modelStr.contains("iPad") {
            if VIDAA_SCREEN_WIDTH > 414 {
                return true
            }
        }
        return false
    }
    
    /**
     * 刘海屏
     */
    class func isIPhoneX() -> Bool {
        return isFullScreen
    }
    
    static var isFullScreen: Bool {
        let screenHeight = UIScreen.main.nativeBounds.size.height
        print(screenHeight)
        if screenHeight == 2436 || screenHeight == 1792 || screenHeight == 2688 || screenHeight == 1624  || screenHeight == 2532 || screenHeight == 2340 || screenHeight == 2778 {
            return true
        }
        return false
    }
    class func gethomeBarHeight() -> CGFloat {
        return homeBarHeight
    }
    static var homeBarHeight: CGFloat {
            var height: CGFloat = 0
            if !isPad() {
                if VIDAA_IS_IPHONEX { //刘海屏幕手机，有homeBar
                    height = 34
                }else {
                    height = 0
                }
                return height
            }
            if isPad(){
                    height = 0.0
            }
            return height
        }
    
}

