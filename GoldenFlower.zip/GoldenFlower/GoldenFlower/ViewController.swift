//
//  ViewController.swift
//  GoldenFlower
//
//  Created by zhaoyang17 on 2022/4/21.
//

import UIKit
import SnapKit
import CocoaLumberjack
import Toaster

let PokerViewWidth = (VIDAA_SCREEN_WIDTH - vidaa_MarginHor(16) * 4) / 3
let PokerViewHeight = floor(PokerViewWidth * 8.8 / 5.7)

let NAV_BGCOLOR = UIColor.v_color(hex: 0x14121B, alpha: 1.0)
let VIDAA_ACCOUNT_GREENCOLOR = UIColor.v_color(hex: 0x6AB67E, alpha: 1.0)
class ViewController: UIViewController{
   
    var poker1:PokerModel?,poker2:PokerModel?,poker3:PokerModel?
    lazy var collectionView : UICollectionView = {
        let flowLayout = UICollectionViewFlowLayout.init()
        flowLayout.scrollDirection = UICollectionView.ScrollDirection.vertical
        flowLayout.itemSize = CGSize(width: PokerViewWidth, height:PokerViewHeight)
        flowLayout.minimumLineSpacing = vidaa_MarginHor(10)
        flowLayout.minimumInteritemSpacing = vidaa_MarginHor(10)
        
        let colloction = UICollectionView(frame: CGRect.zero, collectionViewLayout: flowLayout)
        colloction.backgroundColor = UIColor.clear
        colloction.delegate = self
        colloction.dataSource = self
        colloction.register(PokerSelectCollectionViewCell.self, forCellWithReuseIdentifier: "PokerSelectCollectionViewCell")
        colloction.register(PokerHeadView.self, forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: "cellHeader")
        colloction.showsVerticalScrollIndicator = false
        colloction.showsHorizontalScrollIndicator = false
        colloction.isScrollEnabled = false
        return colloction
    }()
    
    lazy var pokerPicker: PokerPickerView = {
        let picker = PokerPickerView()
        return picker
    }()
    lazy var personCountPicker: PersonCountPicker = {
        let picker = PersonCountPicker()
        return picker
    }()
    lazy var personCountView: UIView = {
        let view = UIView()
        let label:UILabel = UILabel()
        label.text = "玩家总人数:"
        label.font = UIFont.systemFont(ofSize: 16)
        label.textColor = UIColor.white
        view.addSubview(label)
        label.snp_makeConstraints { make in
            make.leading.equalTo(vidaa_MarginHor(0))
            make.centerY.equalTo(view.snp_centerY)
        }
        
        
        
        let line1:UIView = UIView()
        line1.backgroundColor = UIColor.v_color(hex: 0xeeeeee)
        view.addSubview(line1)
        line1.snp_makeConstraints { make in
            make.leading.trailing.top.equalTo(0)
            make.height.equalTo(1.0/UIScreen.main.scale)
        }
        
        let line2:UIView = UIView()
        line2.backgroundColor = UIColor.v_color(hex: 0xeeeeee)
        view.addSubview(line2)
        line2.snp_makeConstraints { make in
            make.leading.trailing.bottom.equalTo(0)
            make.height.equalTo(1.0/UIScreen.main.scale)
        }
        
        view.addSubview(self.personNumLabel)
        personNumLabel.snp_makeConstraints { make in
            make.trailing.equalTo(-vidaa_MarginHor(0))
            make.centerY.equalTo(view.snp_centerY)
        }
        
        let tap = UITapGestureRecognizer.init(target: self, action: #selector(personNumClciked))
        view.addGestureRecognizer(tap)
        return view
    }()
    
    lazy var personNumLabel: UILabel = {
        let label:UILabel = UILabel()
        label.text = String(GameManger.shared.userCount)
        label.font = UIFont.boldSystemFont(ofSize: 16)
        label.textColor = UIColor.white
        return label
    }()
    
    lazy var resultView: CompareResultView = {
        let view = CompareResultView()
        view.clearData()
        return view
    }()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        customNav()
        self.view.addSubview(self.collectionView)
        self.collectionView.reloadData()
        self.collectionView.snp_makeConstraints { make in
            make.leading.equalTo(vidaa_MarginHor(16))
            make.trailing.equalTo(-vidaa_MarginHor(16))
            make.top.equalTo(vidaa_MarginHor(10))
            make.height.equalTo(PokerViewHeight + vidaa_MarginVer(30))
        }
        
        self.view.addSubview(self.personCountView)
        self.personCountView.snp_makeConstraints { make in
            make.leading.equalTo(vidaa_MarginHor(16))
            make.trailing.equalTo(-vidaa_MarginHor(16))
            make.top.equalTo(self.collectionView.snp_bottom).offset(vidaa_MarginHor(8))
            make.height.equalTo(vidaa_MarginHor(44))
        }
        
        self.view.addSubview(self.resultView)
        self.resultView.snp_makeConstraints { make in
            make.leading.equalTo(vidaa_MarginHor(16))
            make.trailing.equalTo(-vidaa_MarginHor(16))
            make.top.equalTo(self.personCountView.snp_bottom).offset(vidaa_MarginHor(8))
            make.bottom.equalTo(self.view.snp_bottom)
        }
    }

    func customNav(){
        if #available(iOS 13.0, *) {
            let appearance = UINavigationBarAppearance()
            appearance.configureWithOpaqueBackground()
            appearance.backgroundColor = NAV_BGCOLOR
            appearance.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white, NSAttributedString.Key.font: UIFont.systemFont(ofSize: 18)]
            appearance.shadowColor = UIColor.clear
            self.navigationController?.navigationBar.standardAppearance = appearance
            self.navigationController?.navigationBar.scrollEdgeAppearance =  self.navigationController?.navigationBar.standardAppearance

        } else {
            // Fallback on earlier versions
        }
       
        


        self.navigationController?.navigationBar.setBackgroundImage(UIImage(named: "bg"), for: .default)
        self.view.backgroundColor = NAV_BGCOLOR
        navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white, NSAttributedString.Key.font: UIFont.systemFont(ofSize: 18)]
        navigationController?.navigationBar.tintColor = UIColor.white
        navigationController?.navigationBar.backgroundColor = UIColor.white
        self.navigationItem.title = "胜率计算器"
//        self.navigationItem.leftBarButtonItem = UIBarButtonItem.init(barButtonSystemItem: UIBarButtonItem.SystemItem.action, target: self, action: #selector(leftClicked))
        self.navigationItem.leftBarButtonItem = UIBarButtonItem.init(image: UIImage.init(named: "info"), landscapeImagePhone: UIImage.init(named: "info"), style: .plain, target: self, action:  #selector(leftClicked))
        self.navigationItem.leftBarButtonItem?.tintColor = VIDAA_ACCOUNT_GREENCOLOR
    }
    @objc func personNumClciked(){
        self.pokerPicker.isHidden = true
        self.pokerPicker.removeFromSuperview()
        self.personCountPicker.deleagte = self
        self.personCountPicker.show(inView: self.view)
        self.personCountPicker.snp_makeConstraints { make in
            make.width.equalTo(SCREEN_WIDTH)
            make.height.equalTo(SCREEN_HEIGHT/2)
            if #available(iOS 11.0, *) {
                make.bottom.equalTo(self.view.snp_bottom).offset(-self.view.safeAreaInsets.bottom)
            } else {
                // Fallback on earlier versions
                make.bottom.equalTo(self.view.snp_bottom)
            }
        }
    }
    @objc func leftClicked(){
        let vc = InfoViewController()
        self.navigationController?.pushViewController(vc, animated: true)
    }

    func showPicker(index:Int){
        self.personCountPicker.isHidden = true
        self.personCountPicker.removeFromSuperview()
        self.pokerPicker.delegate = self
        self.pokerPicker.pokerIndex = index
        self.pokerPicker.show(inView: self.view)
        self.pokerPicker.snp_makeConstraints { make in
            make.width.equalTo(SCREEN_WIDTH)
            make.height.equalTo(SCREEN_HEIGHT/2)
            if #available(iOS 11.0, *) {
                make.bottom.equalTo(self.view.snp_bottom).offset(-self.view.safeAreaInsets.bottom)
            } else {
                // Fallback on earlier versions
                make.bottom.equalTo(self.view.snp_bottom)
            }
        }
    }
    
    
    func beginSimilator(){
        
        if(poker1 != nil && poker2 != nil && poker3 != nil){
            self.resultView.showLoading()
            DispatchQueue.global().async {
                GameManger.shared.delegate = self
                GameManger.shared.setCurrentUserCombination(poker1: self.poker1!, poker2: self.poker2!, poker3: self.poker3!)
            }
            
        }
    }
    
  
}

extension ViewController: UICollectionViewDelegate , UICollectionViewDataSource , UICollectionViewDelegateFlowLayout {
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 3
    }
    
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        if kind == UICollectionView.elementKindSectionHeader {
            let headerView = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: "cellHeader", for: indexPath) as! PokerHeadView
            headerView.delegate = self
            return headerView
        }
        return UICollectionReusableView.init()
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "PokerSelectCollectionViewCell", for: indexPath) as! PokerSelectCollectionViewCell
        if(indexPath.row == 0){
            cell.poker(poker: poker1)
        }else if(indexPath.row == 1){
            cell.poker(poker: poker2)
        }else if(indexPath.row == 2){
            cell.poker(poker: poker3)
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
        return CGSize(width: VIDAA_SCREEN_WIDTH, height: vidaa_MarginVer(30))
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
//        collectionView.deselectItem(at: indexPath, animated: true)
        self.showPicker(index: indexPath.item)
    }
}

extension ViewController:PokerPickerDelegate{
    func pokerDidSelect(dector: PokerDecor, num: PokerNum,pokerIndex: Int) {
        let poker =  PokerModel(num: num, dector: dector)
        var pokerSet:Set = Set<PokerModel>()
        if(poker1 != nil){pokerSet.insert(poker1!)}
        if(poker2 != nil){pokerSet.insert(poker2!)}
        if(poker3 != nil){pokerSet.insert(poker3!)}
    
        var isEqual = false
        for item in pokerSet{
            if(item.isEqualTo(poker: poker)){
                isEqual = true
                break
            }
        }
        if(isEqual){
            ToastView.appearance().backgroundColor = UIColor.v_color(hex: 0xeeeeee)
            ToastView.appearance().textInsets = UIEdgeInsets(top: vidaa_MarginHor(10), left: vidaa_MarginHor(10), bottom: vidaa_MarginHor(10), right: vidaa_MarginHor(10))
            ToastView.appearance().font = UIFont.systemFont(ofSize: 14)
            ToastView.appearance().textColor = UIColor.black
            Toast(text: "已经存在该牌,不允许重复添加").show()
            return
        }
        
        if(pokerIndex == 0){
            poker1 = PokerModel(num: num, dector: dector)
            
        }else if(pokerIndex == 1){
            poker2 = PokerModel(num: num, dector: dector)
        }else if(pokerIndex == 2){
            poker3 = PokerModel(num: num, dector: dector)
        }
        self.collectionView.reloadData()
        self.beginSimilator()
        
    }
}

extension ViewController:PersonCountPickerDelegate{
    func numDidSelect(personCount: Int) {
        GameManger.shared.userCount = personCount
        GameManger.shared.delegate = self
        self.personNumLabel.text = String(personCount)
        self.beginSimilator()
    }
}

extension ViewController:GameMangerDelegate{
    func gameResult(result: Float) {
        DispatchQueue.main.async {
            self.resultView.setResult(prection: result)
        }
        
    }
}

extension ViewController:PokerHeadViewDelegate{
    func clearBtnClicked() {
        self.poker1 = nil
        self.poker2 = nil
        self.poker3 = nil
        self.collectionView.reloadData()
        self.resultView.clearData()
    }
    
    
}
